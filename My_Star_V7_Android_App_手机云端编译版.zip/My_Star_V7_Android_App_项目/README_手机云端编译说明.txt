💙 My Star V7 Android App — 手机云端编译说明

这个版本已经加入 GitHub Actions 自动编译配置。
不需要电脑，也不需要在手机安装 Android Studio。

手机操作流程：
1. 用手机浏览器打开 GitHub，并登录账号。
2. 新建一个 Repository（建议设为 Private）。
3. 把本项目里的所有文件和文件夹上传到 Repository 根目录。
   特别注意：.github/workflows/build-apk.yml 也必须上传。
4. 打开仓库 → Actions → Build My Star APK。
5. 点击 Run workflow → Run workflow。
6. 等待编译完成后，打开成功的工作流程记录。
7. 在 Artifacts 区域下载 MyStar-V7-debug-apk。
8. 解压后得到 app-debug.apk，即可在 Android 手机上安装测试。

注意：
- 这是 Debug APK，适合先测试和给同担小范围安装。
- 如果以后要正式长期发布给很多人使用，建议再制作 Release 签名版，并妥善保存签名密钥。
- GitHub Actions 会自动准备 JDK 17、Gradle 8.7，并执行 Android 构建。
