plugins {
    id("com.android.application")
}

android {
    namespace = "com.mystar.app.v712"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.mystar.app.v712"
        minSdk = 23
        targetSdk = 35
        versionCode = 11
        versionName = "7.1.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            isMinifyEnabled = false
        }
    }
}

configurations.configureEach {
    exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib-jdk7")
    exclude(group = "org.jetbrains.kotlin", module = "kotlin-stdlib-jdk8")
}

dependencies {
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("androidx.activity:activity:1.9.3")
    implementation("androidx.webkit:webkit:1.12.1")
}
