💙My Star💙 V7 Android App

本版本已完善：
1. App 名称：💙My Star💙
2. App 桌面图标：使用你提供的海边星空照片制作。
3. 启动画面：使用同一张照片制作。
4. 现有周边管理网页功能打包进 APK，可离线启动。
5. IndexedDB/本机资料仍然每个安装独立，不会因为同担使用同一个 APK 而共享资料。
6. 支持网页内图片选择、备份/导入等已有功能。
7. Android App 不依赖 Chrome 的“添加到主屏幕”。

如何生成 APK：
- 用 Android Studio 打开本项目文件夹。
- 等待 Gradle Sync 完成。
- Build → Generate App Bundles or APKs → Generate APKs。
- 测试可先生成 debug APK。
- 正式给同担分发时，建议生成 signed release APK。

重要：
当前环境没有完整 Android SDK/Gradle 构建链，因此这里提供完整 Android Studio 项目，不能在此直接输出已签名 APK。


V7.0.1 修复：Android App 的「导出备份」会把 JSON 真正保存到手机 Download 文件夹。
